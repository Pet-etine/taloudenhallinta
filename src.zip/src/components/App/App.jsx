import { useState } from "react";
import ItemForm from "../ItemForm/ItemForm";
import { fetchData } from "../services/uploadData/uploadData"; // Adjust as needed


const App = () => {
    const [importedItem, setImportedItem] = useState(null); // 🔥 Store imported data

    // ✅ Load first item from imported JSON data
    const importData = async () => {
        const jsonData = await fetchData();
        console.log("✅ Imported Data:", jsonData);

        // Select correct array from data.json
        const itemList = jsonData["ALL_Items_Entire_List_"] || jsonData["Activators"] || [];
        
        if (!itemList.length) {
            console.warn("❌ No valid data to import!");
            return;
        }

        setImportedItem(itemList[0]); // 🔥 Store first item in state
    };

    return (
        <div>
            <h1>Data Import</h1>
            <button onClick={importData}>📂 Import Data</button> {/* Import button */}
            <ItemForm importedItem={importedItem} />  {/* ✅ Pass imported data to form */}
        </div>
    );
};

export default App;

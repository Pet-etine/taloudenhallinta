import { useState, useEffect } from "react";
import styles from './ItemForm.module.scss';

const ItemForm = ({ importedItem }) => {
    const [formData, setFormData] = useState({
        "Form Type": "",
        "Form ID": "",
        "Full Name": "",
        "Editor ID": ""
    });

    // ✅ Populate form when importedItem updates
    useEffect(() => {
        if (importedItem) {
            setFormData({
                "Form Type": importedItem["Form Type"] || "",
                "Form ID": importedItem["Form ID"] || "",
                "Full Name": importedItem["Full Name"] || "",
                "Editor ID": importedItem["Editor ID"] || ""
            });
        }
    }, [importedItem]); // 🔥 Runs when importedItem changes

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("✅ Submitted Data:", formData);
    };

    return (
        <div>
            <h2>Add Item</h2>
            <form onSubmit={handleSubmit} className={styles.itemform}>
                <div>
                    <label>Form Type:</label>
                    <input type="text" name="Form Type" value={formData["Form Type"]} onChange={handleChange} />
                </div>
                <div>
                    <label>Form ID:</label>
                    <input type="text" name="Form ID" value={formData["Form ID"]} onChange={handleChange} />
                </div>
                <div>
                    <label>Full Name:</label>
                    <input type="text" name="Full Name" value={formData["Full Name"]} onChange={handleChange} />
                </div>
                <div>
                    <label>Editor ID:</label>
                    <input type="text" name="Editor ID" value={formData["Editor ID"]} onChange={handleChange} />
                </div>
                <button type="submit">➕ Add Item</button>  
            </form>
        </div>
    );
};

export default ItemForm;

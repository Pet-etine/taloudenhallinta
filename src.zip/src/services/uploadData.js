import { app } from "../components/App/firebase";
import { getDatabase, ref, set } from "firebase/database";

// Function to replace invalid characters in keys
function sanitizeKeys(obj) {
    if (typeof obj !== "object" || obj === null) return obj;
    if (Array.isArray(obj)) return obj.map(sanitizeKeys);

    return Object.keys(obj).reduce((acc, key) => {
        const sanitizedKey = key.replace(/[.#$\/[\]]/g, "_"); // Replace invalid characters
        acc[sanitizedKey] = sanitizeKeys(obj[key]); // Recursive cleanup
        return acc;
    }, {});
}

const uploadData = async () => {
    try {
        const response = await fetch("/data.json");
        let data = await response.json();
        data = sanitizeKeys(data); // Clean up keys

        const db = getDatabase(app);
        await set(ref(db, "data/"), data);
        console.log("✅ Data uploaded successfully!");
    } catch (error) {
        console.error("❌ Error uploading data:", error);
    }
};

export default uploadData;
